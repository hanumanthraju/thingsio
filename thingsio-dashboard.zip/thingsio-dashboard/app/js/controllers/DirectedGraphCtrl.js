angular.module('app.controllers')
  .controller('DirectedController', 
  function($scope, $rootScope, $http, $localStorage, SitesFactory, $state, $timeout, Colors) {
 
 $scope.loadDirectedSites = function() {
    $scope.sites = [];
    $scope.data = {};
    SitesFactory.get({ details: 'high' }).$promise.then(function(sites) {
        if (!sites.error) {
            $scope.sites = sites.data;
            formatGrapData(sites.data);
            renderGraph();
            $scope.data.links = [];

            /*var nodeMap = {};
            $scope.data.nodes.forEach(function(x) { nodeMap[x.device_id] = x; });
            $scope.data.links = $scope.data.links.map(function(x) {
            return {
              source: nodeMap[x.site_id],
              target: nodeMap[x.site_id],
              value: 1
            };
            });*/
            console.log('$scope.data', $scope.data)
        }
    })
  }
  $scope.loadDirectedSites();

  function formatGrapData(sitesData){
    var nodes = [];
    $scope.data = {
      nodes: [],
      links: []
    }
    var links = [];
    _.each(sitesData, function(item){
      var node = {
        id:item.site_id,
        site_id:item.site_id,
        name:item.name,
        group:item.site_id
      }
      $scope.data.nodes.push(node);

      if(item.devices && item.devices.length > 0){
        _.each(item.devices, function(device){
        var link =  {
          device_id:device.device_id,
          site_id:device.site_id,
        }
        links.push(link);
      })
      }
    });
    
    $scope.data.links = links;
  }


  function renderGraph(){
    var color = d3.scale.category20();
    $scope.options = {
      chart: {
        type: 'forceDirectedGraph',
        height: 450,
         width: (function(){ return nv.utils.windowSize().width - 450 })(),
        margin:{top: 20, right: 20, bottom: 20, left: 20},
        color: function(d){
            return color(d)
        },
        nodeExtras: function(node) {
          node && node
          .append("text")
          .attr("dx", 8)
          .attr("dy", ".35em")
          .text(function(d) { return d.name })
          .style('font-size', '10px');
        }
      }
    };
  }
});