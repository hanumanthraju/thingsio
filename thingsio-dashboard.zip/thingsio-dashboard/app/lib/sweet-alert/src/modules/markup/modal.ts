import CLASS_NAMES from '../class-list';

const {
  MODAL,
} = CLASS_NAMES;

export const modalMarkup: string =`
  <div class="${MODAL}">` +
    
    // Icon

    // Title

    // Text
  
    // Content
  
    // Buttons

 `</div>`
;

export default modalMarkup;

