import { SwalOptions } from '../options';
export declare const init: (opts: SwalOptions) => void;
export default init;
